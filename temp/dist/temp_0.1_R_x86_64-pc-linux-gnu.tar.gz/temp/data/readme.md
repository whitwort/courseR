# Data sharing

courseR shares data with the course package using the files found here.  If you have concerns about what students can access, setup permissions accordingly after the first package build.
